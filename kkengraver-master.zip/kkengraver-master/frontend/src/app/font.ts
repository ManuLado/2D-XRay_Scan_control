
export class Font  {
    constructor(
        public name?:string,
        public file?:string) {        
    }
}
