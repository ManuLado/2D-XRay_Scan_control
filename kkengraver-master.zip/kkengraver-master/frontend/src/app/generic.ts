export class Generic {
    constructor(public type?: string) {
    }
}
